create view XSST as
(select xs.xm,xs.xh,bj.bm,bj.rs,bj.ms from xs,bj where xs.bjid=bj.bjid)
/

