create trigger S
    before insert
    on XS
    for each row
begin
  insert into xs_insert_log (xh, sj) values (:new.xh, sysdate);
end;
/

